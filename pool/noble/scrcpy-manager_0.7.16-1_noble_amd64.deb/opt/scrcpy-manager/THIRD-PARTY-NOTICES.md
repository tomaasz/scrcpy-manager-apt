# Linux distribution — third-party notices

scrcpy Manager is MIT-licensed (see LICENSE). This preview redistributes the
.NET runtime and Avalonia/Skia/HarfBuzz and their resolved dependencies. Their
original licenses, copyright attributions and third-party notices are in
`licenses/`. `licenses/provenance.json` records exact resolved package versions,
package SHA-256 values, original notice hashes and source URLs. This inventory
also includes unused cross-platform/build assets for completeness.

Avalonia, MicroCom and Tmds.DBus license/notice texts absent from their NuGet
packages are collected from the exact repository commits declared in their
package metadata. Changing dependency versions without matching original
license sources causes the build to fail. Avalonia NOTICE includes additional
attributions and licenses; Skia/HarfBuzz/.NET notices include native components.
Do not remove those notices when redistributing.

ADB, scrcpy, Android, device apps and Linux system libraries are not included
in this archive. They are installed separately and retain their own licenses.
The optional mouse-server patch is generated locally from the user's installed
scrcpy server; no modified scrcpy binary is distributed by this archive.
