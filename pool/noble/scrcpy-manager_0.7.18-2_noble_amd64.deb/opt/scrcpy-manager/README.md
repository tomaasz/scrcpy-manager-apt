# scrcpy Manager — Linux Preview

Pierwsza wersja Linux x64. Okno aplikacji działa bez terminala. Paczka zawiera
.NET, więc nie musisz go instalować. Nie zawiera ADB ani scrcpy.

**Program wymaga dostępu do ekranu (X11/XWayland).** Instalacja na WSL bez WSLg
lub Linuksie bez obsługi okien nie dodaje tej obsługi. Użyj wtedy `scrcpy-manager --web`. Pełny pulpit nie jest
obowiązkowy, ale okna muszą mieć gdzie się wyświetlić.
[Instrukcja dla pulpitu, WSL i komputera bez ekranu](../packaging/linux/GUI.md).

## Nowości 0.7.18

Wybierz zapisaną aplikację: możesz ją skopiować, przesunąć na liście lub pobrać jej
ikonę z wybranego telefonu. Ikona jest zapamiętywana osobno dla każdego telefonu.
Nie pobieramy obrazków ze sklepów i nie instalujemy aplikacji pomocniczej.
Formularz ma obrót obrazu, bufor oraz kodek/jakość dźwięku; tryb „Domyślnie” zostaje
zachowany podczas zapisu. Panel webowy pozwala ustawić dźwięk osobno dla aplikacji.

## Najprostsza instalacja — Ubuntu 24.04 / Debian 13, x64

```sh
curl -fsSL https://tomaasz.github.io/scrcpy-manager-apt/install.sh | sudo sh
```

Jeśli brakuje `curl`, najpierw wpisz `sudo apt install curl`.
Instalator dodaje podpisane repozytorium i instaluje program wraz z ADB i scrcpy.
Nie wymaga konta GitHub ani ręcznego pobierania paczek. Potem otwórz
**scrcpy Manager** z menu aplikacji — bez terminala w tle.

Aktualizacje dostaniesz razem z aktualizacjami systemu. Możesz też wpisać:

```sh
sudo apt update
sudo apt install --only-upgrade scrcpy-manager scrcpy
```

Usunięcie: `sudo apt remove scrcpy-manager`. Ustawienia użytkownika zostają.
Paczki, klucz i instrukcja: [publiczny kanał APT](https://github.com/tomaasz/scrcpy-manager-apt).
Kod aplikacji jest nadal w prywatnym repozytorium. Wersja Linux pozostaje Preview;
obsługiwane są X11/XWayland, bez ARM i natywnego Wayland.

Poniżej pozostaje alternatywna instalacja ręczna ze spakowanego wydania.

## Instalacja krok po kroku — Debian 13 / Ubuntu 24.04, x64

Terminal jest potrzebny tylko do instalacji. Potem uruchamiasz program z menu,
bez terminala w tle. Aplikacji Manager nie uruchamiaj przez `sudo`.

### 1. Pobierz właściwe pliki

Otwórz [wydanie v0.7.16](https://github.com/tomaasz/scrcpy-manager/releases/tag/v0.7.16)
i pobierz z sekcji **Assets**:

- `ScrcpyManager-Linux-x64-preview.tar.gz` — program na Linux x64;
- `ScrcpyManager-Linux-x64-preview.tar.gz.sha256` — suma kontrolna;
- opcjonalnie `INSTALL-LINUX.md` — ta instrukcja do zachowania offline.

Repozytorium jest prywatne: zaloguj się na konto GitHub z dostępem do niego.
Plik `.exe` jest przeznaczony dla Windows. Ta paczka Linux nie działa na ARM,
np. Raspberry Pi. Architekturę komputera sprawdzisz poleceniem `uname -m`;
powinno wyświetlić `x86_64`.

### 2. Zainstaluj potrzebne narzędzia

Na Debian/Ubuntu:

```sh
sudo apt update
sudo apt install adb android-sdk-platform-tools-common python3 curl ca-certificates libx11-6 libice6 libsm6 libfontconfig1 libfreetype6
```

Sprawdź też bibliotekę ICU: na **Debian 13** zainstaluj `sudo apt install libicu76`,
a na **Ubuntu 24.04**: `sudo apt install libicu74`. W innych wersjach systemu
nazwa tego pakietu może być inna. Nie potrzebujesz instalować .NET.

Potrzebne jest również **scrcpy**: co najmniej 2 do ekranu telefonu, a **3 lub
nowsze** do aplikacji w osobnych oknach. Jeśli masz już nowszą wersję w PATH,
sprawdź `scrcpy --version` i przejdź do kroku 3.

Pakiety `apt install scrcpy` mogą być za stare. Gotową wersję x64 można pobrać
z [oficjalnego wydania Genymobile scrcpy 5.0.1](https://github.com/Genymobile/scrcpy/releases/tag/v5.0.1).
Poniższe komendy pobierają ją do katalogu użytkownika, sprawdzają sumę zgodną
z oficjalną instrukcją i udostępniają polecenie `scrcpy`:

```sh
mkdir -p "$HOME/.local/opt" "$HOME/.local/bin"
curl -fL https://github.com/Genymobile/scrcpy/releases/download/v5.0.1/scrcpy-linux-x86_64-v5.0.1.tar.gz -o /tmp/scrcpy-linux-x86_64-v5.0.1.tar.gz
printf '%s  %s\n' '9f969d30cc574816077edecda65719c1c70b0aee1df1ba5fa00779ac07b8fd6e' '/tmp/scrcpy-linux-x86_64-v5.0.1.tar.gz' | sha256sum -c -
```

Kontynuuj tylko, jeśli kontrola sumy zakończyła się **OK**:

```sh
tar -xzf /tmp/scrcpy-linux-x86_64-v5.0.1.tar.gz -C "$HOME/.local/opt"
ln -s "$HOME/.local/opt/scrcpy-linux-x86_64-v5.0.1/scrcpy" "$HOME/.local/bin/scrcpy"
export PATH="$HOME/.local/bin:$PATH"
scrcpy --version
adb version
```

Jeśli `ln` zgłosi, że plik już istnieje, sprawdź posiadaną instalację przez
`command -v scrcpy` i `scrcpy --version`. Nie nadpisuj jej w ciemno.
Po utworzeniu `~/.local/bin` **wyloguj się i zaloguj ponownie**, aby menu
aplikacji również otrzymało właściwy PATH. W Debian/Ubuntu ten katalog jest
dodawany przy logowaniu przez standardowy profil użytkownika. Jeśli masz
własny profil sesji, dodaj do jego PATH `~/.local/bin`.

### 3. Rozpakuj Manager i dodaj skrót

Otwórz terminal w folderze, w którym znajdują się pobrane pliki Managera.
Sprawdź paczkę:

```sh
sha256sum -c ScrcpyManager-Linux-x64-preview.tar.gz.sha256
```

Jeśli wynik to **OK**, wykonaj:

```sh
mkdir -p "$HOME/.local/opt/scrcpy-manager-0.7.16"
tar -xzf ScrcpyManager-Linux-x64-preview.tar.gz -C "$HOME/.local/opt/scrcpy-manager-0.7.16"
cd "$HOME/.local/opt/scrcpy-manager-0.7.16/scrcpy-manager-linux-x64"
sh ./install-desktop.sh
```

Otwórz menu aplikacji i wyszukaj **scrcpy Manager**. Terminal możesz zamknąć.
Możesz też uruchomić plik `scrcpy-manager` dwuklikiem jako program.

Nie przenoś później rozpakowanego katalogu. Jeśli go przeniesiesz, uruchom
`install-desktop.sh` z nowego miejsca. Nie usuwaj katalogu scrcpy z kroku 2 —
Manager korzysta z tego narzędzia przy każdym połączeniu.

### 4. Podłącz telefon

Włącz debugowanie USB w opcjach programisty telefonu. Podłącz kabel do danych,
odblokuj ekran i zaakceptuj zgodę na komputer. W programie kliknij
**Odśwież telefony**, wybierz telefon i **Pokaż ekran telefonu**.

Do połączenia bez kabla użyj **Połącz przez Wi-Fi**. Przy dodawaniu aplikacji
możesz wybrać jej pakiet z telefonu albo wpisać go ręcznie.

### Aktualizacja i usunięcie

Nową wersję rozpakuj do nowego katalogu i uruchom jej `install-desktop.sh`.
Ustawienia i zapisane aplikacje zostają w katalogu użytkownika opisanym niżej.
Po sprawdzeniu nowej wersji możesz usunąć stary katalog Managera.

Aby odinstalować Manager, usuń jego skrót z
`~/.local/share/applications/scrcpy-manager.desktop` (lub z katalogu wskazanego
przez `XDG_DATA_HOME`) i rozpakowany katalog aplikacji. Ustawienia i logi
pozostają do osobnego usunięcia. Nie usuwaj ADB ani scrcpy, jeśli korzystają
z nich inne programy.

### Gdy program nie startuje lub nie widzi telefonu

- **„Nie znaleziono adb/scrcpy”:** sprawdź `adb version` i `scrcpy --version`;
  po dodaniu `~/.local/bin` wyloguj się i zaloguj ponownie.
- **Brak biblioteki ICU/X11:** zainstaluj pakiety z kroku 2. Wymagane jest
  graficzne środowisko X11 lub XWayland i Linux z glibc.
- **Brak uprawnień USB:** zobacz wskazówki udev w sekcji poniżej. Nie uruchamiaj
  Managera jako root, aby obejść problem.
- **Telefon prosi o zgodę:** odblokuj jego ekran i zaakceptuj debugowanie.
- **Nie działa uruchamianie aplikacji:** sprawdź, czy scrcpy ma wersję 3+.
  Telefon też musi obsługiwać wirtualne ekrany.
- **Skrót nie pojawia się w menu:** uruchom ponownie `install-desktop.sh`
  z katalogu aplikacji; w razie potrzeby zaloguj się ponownie.

Przetestowano start paczki na Debian 13 x64 pod Xvfb i Ubuntu 24.04 x64 w CI.
Natywny Wayland, ARM i fizyczny telefon nie są jeszcze potwierdzone testem.

## Telefon przez USB

Włącz opcje programisty i debugowanie USB. Podłącz kabel do przesyłania danych,
odblokuj telefon i zaakceptuj pytanie o zgodę. Kliknij „Odśwież telefony”.
Przy kilku telefonach wybierz jeden z listy.

Jeśli pojawia się brak uprawnień USB, sprawdź reguły udev i grupy użytkownika
w instrukcji Androida dla swojej dystrybucji. Na Debian/Ubuntu reguły dostarcza
pakiet `android-sdk-platform-tools-common`; po zmianie grup wyloguj się i zaloguj.
Program sam nie zmienia grup, nie instaluje sterowników i nie używa sudo.

## Wi-Fi

Kreator prowadzi przez połączenie kablem, parowanie kodem (Android 11+) albo
ponowne połączenie. Port parowania i port połączenia są różne — przepisz je
z odpowiednich ekranów telefonu. mDNS może być blokowane; adres można wpisać
ręcznie. Starszy ADB może wymagać aktualizacji, aby obsłużyć parowanie/mDNS.

Telefon i komputer muszą mieć dostęp do siebie w sieci. Sieć firmowa może to
blokować. USB nie omija ograniczeń sieci. Tryb USB→Wi-Fi włącza na telefonie
ADB TCP na porcie 5555; używaj go w zaufanej sieci. Po pracy wyłącz debugowanie
lub zrestartuj telefon. Dla Android 11+ preferuj parowanie kodem.

## Aplikacje i ustawienia

Dodaj pakiet z telefonu lub wpisz go ręcznie, nadaj nazwę i zapisz. Możesz
ustawić obraz, klawiaturę, mysz i dźwięk. Zapis aplikacji nie instaluje jej
na telefonie. Wirtualne ekrany wymagają obsługi przez telefon i scrcpy 3+.

Windows App/RDP wymaga zgodnego `scrcpy-server` z tego samego wydania co klient.
Program szuka go w `SCRCPY_SERVER_PATH`, obok klienta oraz w katalogach
`share/scrcpy`. Zapisuje poprawkę myszy w katalogu użytkownika; nie zmienia
plików systemowych. Sprawdza wersję w DEX i znany wzorzec bajtów. To kontrola
zgodności, nie dowód pochodzenia pliku. Przy nieznanej wersji blokuje takie
uruchomienie z komunikatem. Pełne działanie RDP wymaga jeszcze testu na telefonie.

Ustawienia: `$XDG_CONFIG_HOME/scrcpy-manager` (domyślnie
`~/.config/scrcpy-manager`). Logi: `$XDG_STATE_HOME/scrcpy-manager`
(domyślnie `~/.local/state/scrcpy-manager`). Uszkodzony plik aplikacji zostaje
zachowany z końcówką `.corrupt-*`; poprzedni poprawny zapis: `.bak`.

To etap Preview: bez paska nawigacji przy oknach, ikon pobieranych z telefonu,
skrótów globalnych i zarządzania monitorami znanego z Windows. Języki: PL/EN;
motyw jasny/ciemny. Repo jest prywatne, ta wersja nie ma aktualizatora GitHub.

Aby usunąć skrót, usuń `scrcpy-manager.desktop` z
`${XDG_DATA_HOME:-~/.local/share}/applications/`. Usunięcie rozpakowanego katalogu
usuwa program; ustawienia i logi pozostają do osobnego usunięcia.

## Budowanie

Wymagane .NET SDK 10, Python 3, tar i sha256sum:

```sh
./scripts/build-linux.sh /tmp/scrcpy-linux-artifacts
```

Skrypt uruchamia testy, buduje paczkę self-contained, zbiera oryginalne licencje
i tworzy SHA-256. Nie publikuje wydania. `licenses/provenance.json` podaje
rzeczywiste wersje i sumy bibliotek oraz źródła tekstów licencji.

## English quick start

Install trusted system `adb` and `scrcpy` (2+ for mirroring, 3+ for app windows).
Extract the archive and launch `scrcpy-manager`. Run `sh install-desktop.sh`
to add a per-user menu shortcut without a terminal. Python 3 is needed only
for shortcut installation. Keep the extracted directory in its final location.
Choose English in the application. Enable USB debugging and authorize the PC,
or follow the Wi-Fi wizard. Phone and computer need network access to each
other. This preview has no GitHub updater. See `THIRD-PARTY-NOTICES.md` and
`licenses/provenance.json` for bundled dependency licenses.

## Linux bez pulpitu — Web Preview (0.7.17)

```sh
scrcpy-manager --web
```

Otwórz pełny jednorazowy link z terminala w aktualnym Chrome lub Edge. W WSL
możesz użyć przeglądarki Windows, bez WSLg. Nie uruchamiaj przez sudo.
Ctrl+C zatrzymuje panel. [Instrukcja i ograniczenia](https://github.com/tomaasz/scrcpy-manager-apt/blob/main/GUI.md).
Testy przeglądarkowe używają materiału testowego; pełna weryfikacja obrazu,
sterowania i dźwięku na fizycznym telefonie pozostaje do wykonania.
