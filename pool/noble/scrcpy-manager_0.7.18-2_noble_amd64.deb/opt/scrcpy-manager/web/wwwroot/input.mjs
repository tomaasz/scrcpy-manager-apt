const keys={Enter:66,Backspace:67,Delete:112,ArrowUp:19,ArrowDown:20,ArrowLeft:21,ArrowRight:22,Home:122,End:123,PageUp:92,PageDown:93,Space:62,ShiftLeft:59,ShiftRight:60,ControlLeft:113,ControlRight:114,AltLeft:57,AltRight:58,MetaLeft:117,MetaRight:118};
for(let i=0;i<26;i++)keys['Key'+String.fromCharCode(65+i)]=29+i;
for(let i=0;i<10;i++)keys['Digit'+i]=7+i;
export function bindInput(canvas,send,onRelease) {
 let active=false,pointer=null;const held=new Map();
 const meta=e=>(e.shiftKey?1:0)|(e.altKey?2:0)|(e.ctrlKey?0x1000:0)|(e.metaKey?0x10000:0);
 const point=e=>{const r=canvas.getBoundingClientRect();return {x:Math.max(0,Math.min(canvas.width-1,Math.floor((e.clientX-r.left)*canvas.width/r.width))),y:Math.max(0,Math.min(canvas.height-1,Math.floor((e.clientY-r.top)*canvas.height/r.height))),width:canvas.width,height:canvas.height};};
 function release() {for(const [key,m] of held)send({type:'key',action:1,key,meta:m});held.clear();active=false;onRelease();}
 canvas.addEventListener('pointerdown',e=>{e.preventDefault();canvas.focus();active=true;pointer=e.pointerId;canvas.setPointerCapture(e.pointerId);send({type:'touch',action:0,...point(e),buttons:0,button:0});});
 canvas.addEventListener('pointermove',e=>{if(pointer===e.pointerId)send({type:'touch',action:2,...point(e),buttons:0,button:0});});
 const up=e=>{if(pointer===e.pointerId){send({type:'touch',action:e.type==='pointercancel'?3:1,...point(e),buttons:0,button:0});pointer=null;}};
 canvas.addEventListener('pointerup',up);canvas.addEventListener('pointercancel',up);
 canvas.addEventListener('wheel',e=>{e.preventDefault();send({type:'scroll',...point(e),scrollX:Math.max(-16,Math.min(16,-e.deltaX/100)),scrollY:Math.max(-16,Math.min(16,-e.deltaY/100)),buttons:0});},{passive:false});
 canvas.addEventListener('contextmenu',e=>e.preventDefault());
 canvas.addEventListener('keydown',e=>{
  if(e.key==='Tab'||e.key==='Escape'){release();if(e.key==='Escape')canvas.blur();return;}
  active=true;const key=keys[e.code];
  if(e.key.length===1&&!e.ctrlKey&&!e.altKey&&!e.metaKey){e.preventDefault();send({type:'text',text:e.key});return;}
  if(key!==undefined){e.preventDefault();held.set(key,meta(e));send({type:'key',action:0,key,meta:meta(e)});}
 });
 canvas.addEventListener('keyup',e=>{const key=keys[e.code];if(held.has(key)){e.preventDefault();send({type:'key',action:1,key,meta:meta(e)});held.delete(key);}});
 canvas.addEventListener('blur',release);window.addEventListener('blur',release);
 return {release};
}
