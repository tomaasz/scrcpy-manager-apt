export function parsePacket(buffer) {
 if(buffer.byteLength<13)throw Error('Truncated media packet');
 const v=new DataView(buffer),channel=v.getUint8(0),flags=v.getBigUint64(1);
 if(channel!==1&&channel!==2)throw Error('Invalid channel');
 if(flags&(1n<<63n)) {
  const w=v.getUint32(5),h=v.getUint32(9);
  if(channel!==1||!w||!h||w>16384||h>16384||buffer.byteLength!==13)throw Error('Invalid dimensions');
  return {channel,size:[w,h]};
 }
 const size=v.getUint32(9);
 if(!size||size>8*1024*1024||buffer.byteLength!==13+size)throw Error('Invalid frame size');
 return {channel,config:!!(flags&(1n<<62n)),key:!!(flags&(1n<<61n)),pts:Number(flags&((1n<<61n)-1n)),payload:new Uint8Array(buffer,13)};
}
export function codecFromAnnexB(bytes) {
 for(let i=0;i+6<bytes.length;i++) {
  let start=-1;
  if(bytes[i]===0&&bytes[i+1]===0&&bytes[i+2]===1)start=i+3;
  else if(bytes[i]===0&&bytes[i+1]===0&&bytes[i+2]===0&&bytes[i+3]===1)start=i+4;
  if(start>=0&&(bytes[start]&31)===7&&start+3<bytes.length)
   return 'avc1.'+[bytes[start+1],bytes[start+2],bytes[start+3]].map(n=>n.toString(16).padStart(2,'0')).join('');
 }
 throw Error('No H.264 SPS configuration');
}
export class PhoneMedia {
 constructor(canvas,onSize,onFailure,onReset,onFrame) {
  this.canvas=canvas;this.context=canvas.getContext('2d',{alpha:false});this.onSize=onSize;this.fail=onFailure;this.reset=onReset;this.onFrame=onFrame;this.keyNeeded=true;this.closed=false;this.frames=0;
 }
 static supported() {return !!(globalThis.isSecureContext&&globalThis.VideoDecoder&&globalThis.EncodedVideoChunk);}
 async enableAudio() {
  if(!globalThis.AudioDecoder||!globalThis.AudioContext)return false;
  try{this.audioContext=new AudioContext({sampleRate:48000,latencyHint:'interactive'});await this.audioContext.resume();return true;}catch{this.disableAudio();return false;}
 }
 receive(buffer) {
  if(this.closed)return;
  const p=parsePacket(buffer);
  if(p.size) {
   [this.canvas.width,this.canvas.height]=p.size;this.onSize(...p.size);this.keyNeeded=true;
   if(this.video&&this.video.state!=='closed')this.video.close();this.video=null;this.config=null;return;
  }
  if(p.channel===2){try{this.audio(p);}catch{this.disableAudio();}return;}
  if(p.config) {
   if(this.video&&this.video.state!=='closed')this.video.close();
   this.config=p.payload.slice();this.keyNeeded=true;
   this.video=new VideoDecoder({output:frame=>{
    try {if(!this.closed){if(this.canvas.width!==frame.displayWidth||this.canvas.height!==frame.displayHeight){this.canvas.width=frame.displayWidth;this.canvas.height=frame.displayHeight;this.onSize(frame.displayWidth,frame.displayHeight);}this.context.drawImage(frame,0,0,this.canvas.width,this.canvas.height);this.frames++;this.onFrame?.(this.frames);}}finally{frame.close();}
   },error:e=>this.fail('Nie można odczytać obrazu. / Video decoder: '+e.message)});
   this.videoConfig={codec:codecFromAnnexB(p.payload),optimizeForLatency:true};this.video.configure(this.videoConfig);return;
  }
  if(!this.video||this.video.state!=='configured')return;
  if(this.video.decodeQueueSize>8) {this.video.reset();this.video.configure(this.videoConfig);this.keyNeeded=true;this.reset();return;}
  if(this.keyNeeded&&!p.key)return;
  let data=p.payload;
  if(p.key&&this.config){data=new Uint8Array(this.config.length+p.payload.length);data.set(this.config);data.set(p.payload,this.config.length);}
  this.video.decode(new EncodedVideoChunk({type:p.key?'key':'delta',timestamp:p.pts,data}));this.keyNeeded=false;
 }
 audio(p) {
  if(!this.audioContext)return;
  if(p.config) {
   if(p.payload.length<19||String.fromCharCode(...p.payload.subarray(0,8))!=='OpusHead')throw Error('Invalid Opus configuration');
   const channels=p.payload[9];if(channels<1||channels>2)throw Error('Unsupported channel count');
   if(this.audioDecoder&&this.audioDecoder.state!=='closed')this.audioDecoder.close();
   this.audioDecoder=new AudioDecoder({output:frame=>{
    try{
     if(this.closed)return;const context=this.audioContext,buffer=context.createBuffer(frame.numberOfChannels,frame.numberOfFrames,frame.sampleRate);
     for(let i=0;i<frame.numberOfChannels;i++)frame.copyTo(buffer.getChannelData(i),{planeIndex:i,format:'f32-planar'});
     const now=context.currentTime;if(!this.audioAt||this.audioAt<now||this.audioAt>now+.25)this.audioAt=now+.03;
     const source=context.createBufferSource();source.buffer=buffer;source.connect(context.destination);source.start(this.audioAt);this.audioAt+=buffer.duration;
    }finally{frame.close();}
   },error:()=>this.disableAudio()});
   this.audioDecoder.configure({codec:'opus',sampleRate:48000,numberOfChannels:channels,description:p.payload});return;
  }
  if(this.audioDecoder?.state==='configured'&&this.audioDecoder.decodeQueueSize<8)
   this.audioDecoder.decode(new EncodedAudioChunk({type:'key',timestamp:p.pts,data:p.payload}));
 }
 disableAudio() {
  if(this.audioDecoder&&this.audioDecoder.state!=='closed')this.audioDecoder.close();
  this.audioContext?.close().catch(()=>{});this.audioContext=null;
  this.fail('Dźwięk jest niedostępny; obraz nadal działa. / Audio unavailable; video continues.');
 }
 close() {
  this.closed=true;
  for(const d of [this.video,this.audioDecoder])if(d&&d.state!=='closed')d.close();
  this.audioContext?.close().catch(()=>{});
 }
}
