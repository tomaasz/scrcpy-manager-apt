import {PhoneMedia} from './media.mjs';
import {bindInput} from './input.mjs';
const $=id=>document.getElementById(id),t=(pl,en)=>$('language').value==='pl'?pl:en;
let csrf='',profiles={apps:[],revision:'empty'},phones=[],editing=-1,socket=null,media=null,busy=false;
function status(text,error=false){$('status').textContent=text;$('status').classList.toggle('error',error);}
function translate(){document.documentElement.lang=$('language').value;document.querySelectorAll('[data-pl]').forEach(e=>{e.textContent=e.dataset[$('language').value];});$('screen').setAttribute('aria-label',t('Obraz telefonu. Kliknij, aby sterować; Tab opuszcza ekran.','Phone image. Click to control; Tab leaves the image.'));renderApps();}
$('language').addEventListener('change',translate);
async function api(path,body,method='POST') {
 const r=await fetch('/api/'+path,{method:body===undefined?'GET':method,headers:body===undefined?{}:{'Content-Type':'application/json','X-Manager-CSRF':csrf},body:body===undefined?undefined:JSON.stringify(body)});
 if(r.status===401){stop();$('workspace').hidden=true;$('login').hidden=false;throw Error(t('Dostęp wygasł. Uruchom serwer ponownie i użyj nowego linku.','Access expired. Restart the server and use its new link.'));}
 if(!r.ok){const b=await r.json().catch(()=>null),error=Error(b?.error||t('Nie udało się wykonać czynności. Sprawdź dane i spróbuj ponownie.','Could not complete the action. Check your input and retry.'));error.status=r.status;throw error;}
 return r.headers.get('Content-Type')?.includes('json')?r.json():null;
}
async function task(fn){if(busy)return;busy=true;$('workspace').setAttribute('aria-busy','true');status(t('Chwileczkę…','Working…'));try{await fn();}catch(e){status(e.message,true);}finally{busy=false;$('workspace').removeAttribute('aria-busy');}}
async function load(){const state=await api('state');csrf=state.csrf;$('appVersion').textContent=state.version;$('login').hidden=true;$('workspace').hidden=false;$('logout').hidden=false;profiles=await api('profiles');renderApps();await refresh();if(profiles.recovered)status(t('Uszkodzona lista aplikacji została zachowana jako kopia. Możesz dodać aplikacje ponownie.','A damaged app list was kept as a backup. Add your apps again.'),true);}
function deviceState(state){const names={device:['Gotowy','Ready'],unauthorized:['Potwierdź zgodę','Authorization needed'],offline:['Rozłączony','Offline'],'no-permissions':['Brak dostępu USB','USB permission needed'],recovery:['Tryb odzyskiwania','Recovery mode']};return names[state]?t(...names[state]):state;}
async function refresh(){const selected=$('devices').value;phones=await api('devices');$('devices').replaceChildren(new Option(t('Wybierz telefon','Choose phone'),''));for(const d of phones)$('devices').add(new Option(`${d.name} · ${deviceState(d.state)}`,d.serial));if(phones.some(d=>d.serial===selected))$('devices').value=selected;else if(phones.length===1)$('devices').value=phones[0].serial;deviceHelp();renderApps();status(phones.length?t('Lista telefonów odświeżona.','Phone list refreshed.'):t('Nie znaleziono telefonu. Sprawdź kabel i debugowanie USB albo połącz przez Wi-Fi.','No phone found. Check USB debugging and cable, or connect over Wi-Fi.'));}
function deviceHelp(){const d=phones.find(d=>d.serial===$('devices').value);$('deviceHelp').textContent=d?.state==='unauthorized'?t('Odblokuj telefon i zaakceptuj zgodę na debugowanie.','Unlock the phone and accept USB debugging.'):d?.state==='no-permissions'?t('Brak dostępu do USB. Podłącz kabel ponownie i sprawdź uprawnienia urządzenia.','USB permission denied. Reconnect and check device permissions.'):d&&d.state!=='device'?t('Telefon nie jest gotowy. Podłącz go ponownie.','Phone is not ready. Reconnect it.') : '';}
function ready(){const d=phones.find(d=>d.serial===$('devices').value);if(d?.state!=='device')throw Error(t('Wybierz gotowy telefon i zaakceptuj zgodę na debugowanie.','Choose a ready phone and authorize USB debugging.'));return d.serial;}
$('devices').addEventListener('change',()=>{deviceHelp();renderApps();});$('refresh').onclick=()=>task(refresh);
$('discoverApps').onclick=()=>task(async()=>{
 $('discoverApps').disabled=true;
 try {
  const serial=ready(),revision=profiles.revision;
  try {
   const result=await api('profiles/discover',{serial,revision});profiles=result.profiles;renderApps();
   status(result.added?t(`Dodano ${result.added} aplikacji.`,`Added ${result.added} apps.`):t('Nie znaleziono nowych znanych aplikacji.','No new known apps found.'));
  } catch(error) {
   if(error.status===409){profiles=await api('profiles');renderApps();}
   throw error;
  }
 } finally {$('discoverApps').disabled=false;}
});
$('loginForm').onsubmit=e=>{e.preventDefault();task(async()=>{await api('login',{token:$('token').value});$('token').value='';await load();});};
$('logout').onclick=()=>task(async()=>{stop();await api('logout',{});location.reload();});
function button(label,action){const b=document.createElement('button');b.type='button';b.textContent=label;b.onclick=action;return b;}
function renderApps(){
 const q=$('search').value.toLowerCase();$('apps').replaceChildren();
 profiles.apps.forEach((a,i)=>{
  if(!`${a.name} ${a.package}`.toLowerCase().includes(q))return;
  const li=document.createElement('li'),heading=document.createElement('div'),icon=document.createElement('span'),name=document.createElement('strong'),pkg=document.createElement('small'),actions=document.createElement('div');
  heading.className='app-heading';icon.className='app-icon';icon.setAttribute('aria-hidden','true');icon.textContent=a.name.slice(0,1).toUpperCase();
  if($('devices').value){const img=document.createElement('img');img.alt='';img.width=44;img.height=44;img.decoding='async';img.hidden=true;img.onload=()=>img.hidden=false;img.onerror=()=>img.hidden=true;img.src='/api/icons/'+encodeURIComponent(a.package)+'?serial='+encodeURIComponent($('devices').value);icon.append(img);}
  name.textContent=a.name;pkg.textContent=a.package;heading.append(icon,name);actions.className='actions';
  const up=button(t('W górę','Move up'),()=>task(()=>moveApp(i,-1))),down=button(t('W dół','Move down'),()=>task(()=>moveApp(i,1)));
  up.disabled=i===0;down.disabled=i===profiles.apps.length-1;
  actions.append(button(t('Otwórz','Open'),()=>task(()=>launch(i))),button(t('Edytuj','Edit'),()=>edit(i)),
   button(t('Duplikuj','Duplicate'),()=>task(()=>duplicateApp(i))),up,down,
   button(t('Ikona z telefonu','Icon from phone'),()=>task(async()=>{await api('icons/'+encodeURIComponent(a.package),{serial:ready()});renderApps();status(t('Pobrano ikonę z telefonu.','Icon loaded from phone.'));})),
   button(t('Usuń','Remove'),()=>remove(i)));
  li.append(heading,pkg,actions);$('apps').append(li);
 });
 if(!$('apps').children.length){const li=document.createElement('li');li.textContent=t('Brak aplikacji. Dodaj pierwszą lub zmień wyszukiwanie.','No apps. Add one or change the search.');$('apps').append(li);}
}
async function saveApps(apps){
 try{profiles=await api('profiles',{revision:profiles.revision,apps},'PUT');renderApps();}
 catch(error){profiles=await api('profiles');renderApps();throw error;}
}
async function duplicateApp(index){
 const apps=structuredClone(profiles.apps),copy=structuredClone(apps[index]);
 copy.name=copy.name.slice(0,110)+t(' (kopia)',' (copy)');apps.splice(index+1,0,copy);
 await saveApps(apps);status(t('Utworzono kopię aplikacji.','App copied.'));
}
async function moveApp(index,direction){
 const apps=structuredClone(profiles.apps),target=index+direction;if(target<0||target>=apps.length)return;
 [apps[index],apps[target]]=[apps[target],apps[index]];await saveApps(apps);status(t('Zmieniono kolejność aplikacji.','App order changed.'));
}
$('search').oninput=renderApps;
function edit(i){editing=i;const a=profiles.apps[i],p=a?.profile;$('appName').value=a?.name||'';$('package').value=a?.package||'';$('displaySize').value=p?.displaySize||'1920x1080/160';$('maxFps').value=p?.maxFps||30;$('bitrate').value=p?.videoBitRate||'4M';$('profileAudio').value=p?.audioMode||'global';$('profileWarning').textContent='';$('editor').showModal();}
$('addApp').onclick=()=>edit(-1);$('cancelEdit').onclick=()=>$('editor').close();
$('loadPackages').onclick=()=>task(async()=>{const packages=await api('packages?serial='+encodeURIComponent(ready()));$('packages').replaceChildren(...packages.map(p=>new Option(p,p)));status(t('Lista pakietów gotowa. Zacznij wpisywać nazwę w polu pakietu.','Package list ready. Start typing in the package field.'));});
$('profileForm').onsubmit=e=>{e.preventDefault();task(async()=>{const original=editing<0?null:profiles.apps[editing];const entry=original?structuredClone(original):{flags:[],profile:{preset:'default',videoCodec:'h264',keyboardMode:'sdk',mouseMode:'sdk',audioMode:'global',orientation:'auto',taskbarMode:'global'}};entry.name=$('appName').value;entry.package=$('package').value;Object.assign(entry.profile,{displaySize:$('displaySize').value,maxFps:Number($('maxFps').value),videoBitRate:$('bitrate').value,audioMode:$('profileAudio').value});const apps=structuredClone(profiles.apps);if(editing<0)apps.push(entry);else apps[editing]=entry;try{profiles=await api('profiles',{revision:profiles.revision,apps},'PUT');$('editor').close();renderApps();status(t('Zapisano aplikację.','App saved.'));}catch(e){$('profileWarning').textContent=e.message;profiles=await api('profiles');renderApps();throw e;}});};
async function remove(i){$('removeName').textContent=profiles.apps[i].name;const d=$('removeDialog');d.returnValue='';d.showModal();d.addEventListener('close',()=>{if(d.returnValue==='remove')task(async()=>{profiles=await api('profiles',{revision:profiles.revision,apps:profiles.apps.filter((_,n)=>n!==i)},'PUT');renderApps();status(t('Usunięto zapis.','Entry removed.'));});},{once:true});}
function wifiStatus(s){const messages={Connected:['Połączono telefon.','Phone connected.'],PairedNeedsAddress:['Sparowano. Podaj teraz adres z głównego ekranu debugowania bezprzewodowego.','Paired. Enter the connection address from the main wireless debugging screen.'],InvalidEndpoint:['Sprawdź adres IP i port.','Check the IP address and port.'],InvalidCode:['Wpisz 6 cyfr z telefonu.','Enter the 6 digits from the phone.'],PairingFailed:['Kod mógł wygasnąć. Otwórz nowe okno parowania na telefonie.','The code may have expired. Open a new pairing dialog on the phone.']};const m=messages[s];status(m?t(...m):t('Nie połączono. Sprawdź telefon, sieć i adres.','Connection failed. Check the phone, network and address.'),s!=='Connected'&&s!=='PairedNeedsAddress');}
$('connectForm').onsubmit=e=>{e.preventDefault();task(async()=>{const r=await api('wifi/connect',{address:$('address').value});await refresh();wifiStatus(r.status);});};
$('pairForm').onsubmit=e=>{e.preventDefault();const code=$('pairCode').value;$('pairCode').value='';task(async()=>{const r=await api('wifi/pair',{address:$('pairAddress').value,code});await refresh();wifiStatus(r.status);});};
$('usbWifi').onclick=()=>task(async()=>{const r=await api('wifi/usb',{serial:ready()});await refresh();wifiStatus(r.status);});
function send(input){if(socket?.readyState===WebSocket.OPEN)socket.send(JSON.stringify(input));}
const input=bindInput($('screen'),send,()=>{});
function controls(active){$('audio').disabled=active;for(const id of ['stop','back','home','recents','pasteText','getClipboard'])$(id).disabled=!active;}
function stop(){input.release();if(socket){socket.onclose=null;socket.close();socket=null;}media?.close();media=null;controls(false);$('screen').hidden=true;$('placeholder').hidden=false;$('sessionStatus').textContent=t('Sesja zakończona.','Session ended.');}
async function launch(index){const serial=ready();if(!PhoneMedia.supported())throw Error(t('Obraz wymaga aktualnego Chrome lub Edge z WebCodecs. Otwórz panel w tej przeglądarce.','Video needs current Chrome or Edge with WebCodecs. Open the panel there.'));stop();$('audio').disabled=true;try{$('sessionStatus').textContent=t('Łączenie z telefonem…','Connecting to the phone…');media=new PhoneMedia($('screen'),()=>{},message=>status(message,true),()=>send({type:'resetVideo'}),count=>{if(count!==1)return;$('placeholder').hidden=true;$('screen').hidden=false;$('sessionStatus').textContent=t('Obraz połączony.','Video connected.');});const mode=index===undefined?'global':profiles.apps[index].profile.audioMode;const wantsAudio=mode==='on'||(mode!=='off'&&$('audio').checked);const audio=wantsAudio&&await media.enableAudio();const url=new URL('/api/session',location.href);url.protocol='ws:';url.searchParams.set('serial',serial);url.searchParams.set('audio',String(audio));if(index!==undefined){url.searchParams.set('app',index);url.searchParams.set('revision',profiles.revision);}await api('session-check'+url.search);socket=new WebSocket(url);socket.binaryType='arraybuffer';const current=socket;current.onopen=()=>{controls(true);status(t('Połączono. Czekam na obraz telefonu.','Connected. Waiting for video.'));};current.onmessage=e=>{if(current!==socket)return;try{if(typeof e.data==='string'){const m=JSON.parse(e.data);if(m.type==='error')status(m.message,true);if(m.type==='audioUnavailable')status(t('Telefon nie udostępnia dźwięku. Obraz może działać dalej.','Phone audio is unavailable. Video can continue.'));if(m.type==='clipboard'){$('clipboard').value=m.text;status(t('Pobrano schowek do pola tekstowego.','Phone clipboard loaded into the text field.'));}}else media.receive(e.data);}catch(error){status(error.message,true);stop();}};current.onclose=()=>{if(current===socket){stop();status(t('Sesja została zakończona. Sprawdź połączenie lub profil i spróbuj ponownie.','Session ended. Check connection or profile and retry.'),true);}};current.onerror=()=>status(t('Nie udało się otworzyć sesji. Sprawdź telefon, zgodność profilu i czy inna karta już nim steruje.','Cannot open session. Check phone, profile compatibility and other controlling tabs.'),true);}catch(error){stop();throw error;}}
$('mirror').onclick=()=>task(()=>launch());$('stop').onclick=stop;
for(const [id,key] of [['back',4],['home',3],['recents',187]])$(id).onclick=()=>{send({type:'key',action:0,key});send({type:'key',action:1,key});};
$('clipboardForm').onsubmit=e=>{e.preventDefault();send({type:'clipboard',text:$('clipboard').value});};$('getClipboard').onclick=()=>send({type:'getClipboard'});
window.addEventListener('pagehide',stop);
async function initialize(){const fragment=new URLSearchParams(location.hash.slice(1)),token=fragment.get('login');history.replaceState(null,'',location.pathname);try{if(token)await api('login',{token});await load();}catch(e){status(e.message,true);}}
translate();initialize();
